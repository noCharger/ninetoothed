import torch

def solve(x, BLOCK_SIZE=32):
    # Create an output tensor of the same shape as x
    y = torch.zeros_like(x)

    # Define the ReLU kernel using PyTorch operations
    y = torch.max(x, torch.tensor(0, device=x.device, dtype=x.dtype))

    return y
