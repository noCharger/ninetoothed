import numpy as np
import ninetoothed as nt

@nt.arrangement
def arrangement(a, b):
    return a.tile((1,)), b.tile((1,))

@nt.application
def application(a_tile, b_tile):
    return a_tile * b_tile

kernel = nt.make(arrangement, application, (nt.Tensor(2), nt.Tensor(2)))

def solve(a, b, BLOCK_SIZE=8):
    M, N = a.shape[0], b.shape[1]
    output = np.empty((M, N), dtype=a.dtype)
    kernel(a, b, output, BLOCK_SIZE=BLOCK_SIZE)
    return output
