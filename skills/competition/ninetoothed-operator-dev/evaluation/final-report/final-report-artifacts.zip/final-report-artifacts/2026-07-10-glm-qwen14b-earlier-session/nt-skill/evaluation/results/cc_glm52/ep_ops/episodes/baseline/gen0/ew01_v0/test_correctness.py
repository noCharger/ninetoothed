"""
Correctness tests for 1-D elementwise add (out = a + b).

Matrix: shape × dtype × layout. Includes non-power-of-two shapes, an empty
tensor, and a non-contiguous (strided) input.
"""

import itertools

import pytest
import torch

from wrapper import solve

pytestmark = pytest.mark.skipif(
    not torch.cuda.is_available(), reason="CUDA not available"
)

DEVICE = "cuda"
TOL = {
    torch.float32: dict(atol=1e-6, rtol=1e-6),
    torch.float16: dict(atol=1e-3, rtol=1e-3),
}

# 1-D shapes: edge sizes, non-power-of-two, and a large size split across tiles.
SHAPES = [1, 7, 1024, 1025, 65536, 100003]
DTYPES = [torch.float32, torch.float16]


@pytest.mark.parametrize(
    "shape,dtype",
    list(itertools.product(SHAPES, DTYPES)),
)
def test_add(shape, dtype):
    a = torch.randn(shape, dtype=dtype, device=DEVICE)
    b = torch.randn(shape, dtype=dtype, device=DEVICE)

    expected = a + b
    got = solve(a, b)

    assert got.shape == expected.shape
    assert got.dtype == expected.dtype
    torch.testing.assert_close(got, expected, **TOL[dtype])


@pytest.mark.parametrize("dtype", DTYPES)
def test_non_contiguous(dtype):
    """Strided (stride-2) view: wrapper makes contiguous before the kernel."""
    n = 2048
    a_full = torch.randn(n * 2, dtype=dtype, device=DEVICE)
    b_full = torch.randn(n * 2, dtype=dtype, device=DEVICE)
    a = a_full[::2]  # non-contiguous
    b = b_full[::2]
    assert not a.is_contiguous()

    expected = a + b
    got = solve(a, b)
    torch.testing.assert_close(got, expected, **TOL[dtype])


@pytest.mark.parametrize("dtype", DTYPES)
def test_inputs_modified(dtype):
    """The kernel must not mutate its input tensors."""
    n = 1024
    a = torch.randn(n, dtype=dtype, device=DEVICE)
    b = torch.randn(n, dtype=dtype, device=DEVICE)
    a_clone = a.clone()
    b_clone = b.clone()
    _ = solve(a, b)
    torch.testing.assert_close(a, a_clone, atol=0, rtol=0)
    torch.testing.assert_close(b, b_clone, atol=0, rtol=0)


def test_zero_size():
    a = torch.zeros(0, dtype=torch.float32, device=DEVICE)
    b = torch.zeros(0, dtype=torch.float32, device=DEVICE)
    got = solve(a, b)
    assert got.numel() == 0
    torch.testing.assert_close(got, a + b, atol=0, rtol=0)


def test_mismatched_shape_raises():
    a = torch.randn(8, dtype=torch.float32, device=DEVICE)
    b = torch.randn(16, dtype=torch.float32, device=DEVICE)
    with pytest.raises(ValueError):
        solve(a, b)
