import numpy as np
import ninetoothed as nt
from kernel import relu_kernel

def solve(x):
    if x.dtype == np.float32:
        BLOCK_SIZE = 32
    elif x.dtype == np.float16:
        BLOCK_SIZE = 64
    else:
        raise ValueError("Unsupported dtype")

    output = np.empty_like(x)
    relu_kernel(x, output=output, BLOCK_SIZE=BLOCK_SIZE)
    return output
