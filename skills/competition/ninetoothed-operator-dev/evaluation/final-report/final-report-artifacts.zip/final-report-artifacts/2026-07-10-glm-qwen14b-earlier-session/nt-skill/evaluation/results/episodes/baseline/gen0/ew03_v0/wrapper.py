# wrapper.py
import ninetoothed
import ninetoothed.language as ntl
from ninetoothed import Symbol, Tensor
import torch

BLOCK_SIZE = Symbol("BLOCK_SIZE", constexpr=True)

def arrangement(input, output, BLOCK_SIZE=BLOCK_SIZE):
    return (input.tile((BLOCK_SIZE,)),
            output.tile((BLOCK_SIZE,)))

def application(input, output):
    output = ntl.where(input > 0, input, 0.0)  # noqa: F841

kernel = ninetoothed.make(arrangement, application, (Tensor(1), Tensor(1)))

def solve(input):
    output = torch.empty_like(input)
    kernel(input, output, BLOCK_SIZE=1024)  # constexpr passed at call
    return output
