"""NineToothed kernel for 1-D elementwise addition: out = a + b.

a and b are same-shape 1-D tensors. The kernel tiles them along their single
dimension into blocks of ``BLOCK_SIZE`` elements; NineToothed auto-masks the
tail block, so the length need not be a multiple of ``BLOCK_SIZE``.

The symbolic tensors are declared without a fixed dtype, so the same generated
kernel serves both ``fp32`` and ``fp16`` inputs — the runtime dtype is taken
from the torch tensors passed in by the wrapper.
"""

import ninetoothed
from ninetoothed import Symbol, Tensor

# Power-of-two block size, tuned by the caller / auto-tuner. Kept constexpr so
# Triton can unroll the inner loop and use vectorized loads/stores.
BLOCK_SIZE = Symbol("BLOCK_SIZE", constexpr=True)


def arrangement(a, b, output, BLOCK_SIZE=BLOCK_SIZE):
    """Tile each 1-D tensor into contiguous blocks of ``BLOCK_SIZE``."""
    return (
        a.tile((BLOCK_SIZE,)),
        b.tile((BLOCK_SIZE,)),
        output.tile((BLOCK_SIZE,)),
    )


def application(a, b, output):
    output = a + b  # noqa: F841  (assignment to `output` emits the store)


# 1-D symbolic tensors; dtype left unset so fp32 / fp16 are both handled.
_TENSORS = (Tensor(1), Tensor(1), Tensor(1))

kernel = ninetoothed.make(arrangement, application, _TENSORS)
