# stub kernel
def kernel():
    return 0
