# wrapper.py
import ninetoothed
import ninetoothed.language as ntl
from ninetoothed import Symbol, Tensor
import torch

BLOCK_SIZE = Symbol("BLOCK_SIZE", constexpr=True)

def arrangement(a, b, output, BM=Symbol("BM", constexpr=True), BN=Symbol("BN", constexpr=True)):
    return (a.tile((BM, 1)), b.tile((1, BN)), output.tile((BM, BN)))

def application(a, b, output):
    output = a * b  # noqa: F841

kernel = ninetoothed.make(arrangement, application, (Tensor(1), Tensor(1), Tensor(1)))

def solve(a, b, BLOCK_SIZE=1024):
    output = torch.empty_like(a)
    kernel(a, b, output=output, BLOCK_SIZE=BLOCK_SIZE)
    return output
