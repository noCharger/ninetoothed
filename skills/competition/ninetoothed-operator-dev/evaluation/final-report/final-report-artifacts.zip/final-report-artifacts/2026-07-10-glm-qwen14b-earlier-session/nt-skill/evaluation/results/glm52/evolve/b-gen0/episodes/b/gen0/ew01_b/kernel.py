"""NineToothed kernel for 1D elementwise addition: out = a + b.

Supports fp32 and fp16. Handles non-power-of-two shapes via `other=` padding
on source tensors so out-of-range loads are well-defined (boundary writes to
the output are masked automatically by the generated Triton code).
"""

import ninetoothed
import ninetoothed.language as ntl
from ninetoothed import Symbol, Tensor

BLOCK_SIZE = Symbol("BLOCK_SIZE", constexpr=True)


def arrangement(input, other, output, BLOCK_SIZE=BLOCK_SIZE):
    # Tile every tensor the same way along the single dimension.
    return (
        input.tile((BLOCK_SIZE,)),
        other.tile((BLOCK_SIZE,)),
        output.tile((BLOCK_SIZE,)),
    )


def application(input, other, output):
    output = input + other  # noqa: F841  (assign to output param; expected)


# `other=0.0` on the source tensors ensures OOB loads read 0.0 for tiles that
# straddle the tensor edge (non-divisible shapes). Output writes are masked.
kernel = ninetoothed.make(
    arrangement,
    application,
    (Tensor(1, other=0.0), Tensor(1, other=0.0), Tensor(1)),
)
