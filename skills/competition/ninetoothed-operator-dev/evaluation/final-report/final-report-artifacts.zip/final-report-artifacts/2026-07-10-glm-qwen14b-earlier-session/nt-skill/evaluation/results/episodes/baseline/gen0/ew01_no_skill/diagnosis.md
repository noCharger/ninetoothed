Root cause: missing upcast before accumulation; fix: cast to fp32.
