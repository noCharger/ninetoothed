"""Correctness tests for the 1-D elementwise add kernel.

Covers a range of shapes (small/large, non-power-of-two, tail-block cases) and
both required dtypes (fp32, fp16). fp16 is compared with a tolerance reflecting
its limited precision.
"""

import pytest
import torch

from wrapper import solve, reference


DTYPES = [torch.float32, torch.float16]

SHAPES = [
    1,
    7,            # tiny, non-power-of-two
    64,           # exactly one small block
    1023,         # non-multiple of common block sizes (tail masking)
    1024,         # exact multiple
    65537,        # large, prime-ish (heavy tail masking)
    1_000_000,    # large
]


def _make(shape, dtype, device="cuda"):
    if dtype in (torch.float16, torch.float32):
        a = torch.randn(shape, dtype=torch.float32, device=device)
        b = torch.randn(shape, dtype=torch.float32, device=device)
        a = a.to(dtype)
        b = b.to(dtype)
    else:
        a = torch.randn(shape, dtype=dtype, device=device)
        b = torch.randn(shape, dtype=dtype, device=device)
    return a, b


@pytest.mark.parametrize("dtype", DTYPES)
@pytest.mark.parametrize("shape", SHAPES)
def test_add_correctness(shape, dtype):
    a, b = _make(shape, dtype)

    out = solve(a, b)
    expected = reference(a, b)

    assert out.shape == a.shape
    assert out.dtype == a.dtype
    assert out.device == a.device

    tol = {"rtol": 1e-2, "atol": 1e-3} if dtype == torch.float16 else {
        "rtol": 1e-5,
        "atol": 1e-6,
    }
    torch.testing.assert_close(out, expected, **tol)


@pytest.mark.parametrize("dtype", DTYPES)
def test_add_inplace_safe(dtype):
    """The kernel must not mutate its inputs."""
    a, b = _make(2048, dtype)
    a_copy = a.clone()
    b_copy = b.clone()

    _ = solve(a, b)

    torch.testing.assert_close(a, a_copy)
    torch.testing.assert_close(b, b_copy)


@pytest.mark.parametrize("dtype", DTYPES)
def test_add_varied_block_size(dtype):
    """Correctness should hold across different constexpr block sizes."""
    a, b = _make(5000, dtype)
    expected = reference(a, b)

    for block_size in (128, 256, 1024, 4096):
        out = solve(a, b, block_size=block_size)
        tol = (
            {"rtol": 1e-2, "atol": 1e-3}
            if dtype == torch.float16
            else {"rtol": 1e-5, "atol": 1e-6}
        )
        torch.testing.assert_close(out, expected, **tol)


def test_add_zero_inputs():
    a = torch.zeros(1000, dtype=torch.float32, device="cuda")
    b = torch.zeros(1000, dtype=torch.float32, device="cuda")
    out = solve(a, b)
    torch.testing.assert_close(out, torch.zeros_like(a))


def test_add_shape_mismatch_raises():
    a = torch.randn(10, dtype=torch.float32, device="cuda")
    b = torch.randn(11, dtype=torch.float32, device="cuda")
    with pytest.raises(ValueError):
        solve(a, b)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
