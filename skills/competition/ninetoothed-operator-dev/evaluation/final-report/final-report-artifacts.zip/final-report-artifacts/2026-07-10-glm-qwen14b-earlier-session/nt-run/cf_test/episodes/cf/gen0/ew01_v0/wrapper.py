# wrapper.py
import ninetoothed
import ninetoothed.language as ntl
from ninetoothed import Symbol, Tensor, block_size
import torch

BLOCK_SIZE = Symbol("BLOCK_SIZE", constexpr=True)

def arrangement(a, b, c, BLOCK_SIZE=BLOCK_SIZE):
    return (a.tile((BLOCK_SIZE,)), b.tile((BLOCK_SIZE,)), c.tile((BLOCK_SIZE,)))

def application(a, b, c):
    c = a + b  # noqa: F841

kernel = ninetoothed.make(arrangement, application, (Tensor(1), Tensor(1), Tensor(1)))

def solve(a, b):
    c = torch.empty_like(a)
    kernel(a, b, c, BLOCK_SIZE=1024)  # Replace with a fixed BLOCK_SIZE value
    return c
