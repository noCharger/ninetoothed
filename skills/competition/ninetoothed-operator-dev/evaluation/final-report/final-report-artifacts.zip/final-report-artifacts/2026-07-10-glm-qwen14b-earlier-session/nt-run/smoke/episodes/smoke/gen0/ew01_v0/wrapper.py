import torch
from kernel import add

def solve(a, b):
    output = torch.empty_like(a)
    add(a, b, output, BLOCK_SIZE=1024)
    return output
