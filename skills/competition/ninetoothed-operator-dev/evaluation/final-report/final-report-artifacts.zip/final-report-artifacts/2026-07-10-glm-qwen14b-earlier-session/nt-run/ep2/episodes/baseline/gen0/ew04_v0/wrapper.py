# wrapper.py
import ninetoothed
import ninetoothed.language as ntl
from ninetoothed import Symbol, Tensor, block_size
import torch

BLOCK_SIZE = Symbol("BLOCK_SIZE", constexpr=True)

def arrangement(input, output, BLOCK_SIZE=BLOCK_SIZE):
    return (input.tile((BLOCK_SIZE,)),
            output.tile((BLOCK_SIZE,)))

def application(input, output):
    output = ntl.where(input > 0, input * (1 + 0.044715 * input * input * (1 + 0.34785 * input * input)), 0.0)  # noqa: F841

kernel = ninetoothed.make(arrangement, application, tuple(Tensor(1) for _ in range(2)))

def solve(input):
    output = torch.empty_like(input)
    kernel(input, output, BLOCK_SIZE=1024)
    return output
